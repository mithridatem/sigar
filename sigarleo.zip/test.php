<?php

    $test1 =1;
    $test2 =3;
    if($test2==3){
        echo 'toto';
    }

?>