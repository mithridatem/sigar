<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGAR</title>
    <link rel="icon"  href="./css/img/adrar-favicon.png">
    <link rel="stylesheet" href="./css/customTheme.css">
</head>