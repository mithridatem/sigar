

    <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="./css/img/logo_adrar.jpg" height="75px">
                <img src="./css/img/2019_LOGO_POLE_NUM_white.png" height="75px">
                
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-md-end " id="navbarNavAltMarkup">
                <ul class="navbar-nav">
                    
                    <li class="nav-item">
                        <a href="./index.php" class="nav-link">Connexion</a>
                    </li>
                    <li class="nav-item">
                        <a href="createFormateur.php" class="nav-link">Ajout formateur</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    

    <?php

    ?>