<?php
    //ajout de la vue
    include('view/viewCreateFormateur.php');
    //ajout du model
    include('model/utilisateur.php');
    //ajout util
    include('utils/connectBdd.php');
    //ajout api
    include('api/createFormateur.php');
?>